------------------
Django Taobao
------------------

a django plugin allow you to login with Taobao account, and view/edit your sold items.